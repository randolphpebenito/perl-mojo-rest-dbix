/*
  Parse JSON from C into json_output_t structures.


*/

#ifdef HEADER

typedef json_parse_status_t (* 

typedef struct json_parse {
    
}
json_parse_t;

#endif /* def HEADER */

json_parse (
